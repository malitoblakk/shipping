from django.urls import path
from Logapp.views import HomeView, TrackingView

urlpatterns = [

    path('', HomeView, name="home" ),
    path('tracking', TrackingView, name="Tracking"),

]