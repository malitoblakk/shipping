from email import message
from unicodedata import name
from django.shortcuts import render
from django.contrib import messages
from .models import TrackingDetail

# Create your views here.



def HomeView(request):

    context = {}
    return render (request, 'index.html', context)

def TrackingView(request):
    tracking = TrackingDetail.objects.all()

    context = {

        'tracking':tracking
    
    }

    return render(request, 'trackingpage.html', context)
