from email.message import Message
from pyexpat import model
from django.db import models

# Create your models here.



# class Contact(models.Model):
#     FORMS_NEED = [
#             ('Content','Submit a Content'),
#             ('Report','Report a Content'),
#             ('Compain','Make a complian'),
#             ('Other','Other'),
#     ]
#     firtname = models.CharField(max_length=50, blank=False, null=False)
#     lastname = models.CharField(max_length=200,blank=False, null=False)
#     email = models.EmailField()
#     forms_need = models.CharField(max_length=100, choices=FORMS_NEED, blank=False, null=False)
#     de_message = models.TextField()

class TrackingDetail(models.Model):
    # ACTIVENESS = [

    #     ('order_proceded', 'active'),
    #     ('order_shipped', 'active'),
    #     ('order_route', 'active'),
    #     ('order_arrived', 'active'),
    # ]
    tracking_id = models.CharField(max_length=50, blank=False,null=False)
    expected_arrival = models.CharField(max_length=50, blank=False,null=False)
    usps_trackingcode = models.CharField(max_length=100, blank=False,null=False)
    order_processed = models.CharField(max_length=50,  blank=True,null=True)
    processed_date = models.CharField(max_length=20, blank=True, null=True)
    order_shipped = models.CharField(max_length=50, blank=True,null=True)
    shipped_date = models.CharField(max_length=20, blank=True, null=True)
    order_route = models.CharField(max_length=50,  blank=True,null=True)
    route_date = models.CharField(max_length=20, blank=True, null=True)
    order_arrived = models.CharField(max_length=50, blank=True,null=True)
    arrived_date = models.CharField(max_length=20, blank=True, null=True)


    

    def __str__(self):
        return self.tracking_id
    class Meta:
        verbose_name = 'TrackingDetail'
        verbose_name_plural = 'TrackingDetails'